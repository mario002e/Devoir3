package GrilleImpl;

import static org.junit.Assert.*;

import org.junit.Test;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;

public class GrilleTest {

	private int[][] sudoku = {
			{8,6,0,0,2,0,0,0,0},
			{0,0,0,7,0,0,0,5,9},
			{0,0,0,0,0,0,0,0,0},
			{0,0,0,0,6,0,8,0,0},
			{0,4,0,0,0,0,0,0,0},
			{0,0,5,3,0,0,0,0,7},
			{0,0,0,0,0,0,0,0,0},
			{0,2,0,0,0,0,6,0,0},
			{0,0,7,5,0,9,0,0,0}
	};
	private Grille grille;
	
	@Before
	public void initGrille() {
		grille = new Grille();
	}

	@Test
	public void testGetRow() {
		int[] row5 = {0,0,5,3,0,0,0,0,7};
		assertTrue(Arrays.equals(row5, grille.getRow(5)));
	}

	@Test
	public void testGetColumn() {
		int[] col5 = {0,0,0,0,0,0,0,0,9};
		assertTrue(Arrays.equals(col5, grille.getColumn(5)));
	}

	@Test
	public void testGetRegion() {
	    int[] region3 = {0,0,0,0,5,9,0,0,0};
	    assertTrue(Arrays.equals(region3, grille.getRegion(2, 8)));
	}

	@Test
	public void testGetCell() {
		assertEquals(4,grille.getCell(4, 1));
	}

	@Test
	public void testSetCell() {
		grille.setCell(4, 1, 2);
		assertEquals(2,grille.getCell(4, 1));
	}

	@Test
	public void testToString() {
		final String expectedOutput = 
				" -------------------------\n" + 
				" | 8 6 _ | _ 2 _ | _ _ _ |\n" + 
				" | _ _ _ | 7 _ _ | _ 5 9 |\n" + 
				" | _ _ _ | _ _ _ | _ _ _ |\n" + 
				" -------------------------\n" + 
				" | _ _ _ | _ 6 _ | 8 _ _ |\n" + 
				" | _ 4 _ | _ _ _ | _ _ _ |\n" + 
				" | _ _ 5 | 3 _ _ | _ _ 7 |\n" + 
				" -------------------------\n" + 
				" | _ _ _ | _ _ _ | _ _ _ |\n" + 
				" | _ 2 _ | _ _ _ | 6 _ _ |\n" + 
				" | _ _ 7 | 5 _ 9 | _ _ _ |\n" + 
				" -------------------------\n"; 
		assertEquals(expectedOutput, grille.toString());
	}
}
